<?php
namespace App\Config;

class Appconf {
   
    const DBHOST        = 'localhost';
    const DBNAME        = 'teste';
    const DBUSER        = 'root';
    const DBPASSWORD    = '';
    const DBDRIVER      = 'mysql';
    const DBCHARSET     = 'utf8';   
    
}